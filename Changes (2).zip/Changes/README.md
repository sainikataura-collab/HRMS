# Task Management System - Complete Changes Export

This directory contains all the backend, frontend, and database files developed and modified for the Task Management System (Kanban workspace, SLA recurrence engine, role-scoped visibility, real-time SignalR notifications & Web Audio toast chime).

---

## Directory Structure

### 1. `Frontend/`
* `src/app/pages/task-manager/`
  * `task-manager.component.*`: Main Kanban workspace, search, filters, stats, recurring tasks tab.
  * `components/create-task-modal/`: Large 2-column modal, recurrence scheduler, SLA duration calculator, live dossier preview.
  * `components/task-detail-drawer/`: Slide-over detail drawer, audit timeline, status action chips, attachments.
  * `components/transition-remarks-modal/`: Mandatory remarks modal on status transition.
  * `components/task-toast-notification/`: Modern SaaS bottom-right animated toast popup with countdown timer bar.
* `src/app/shared/services/`
  * `task-manager.service.ts`: REST API client for task operations and board fetching.
  * `task-toast.service.ts`: Toast state & Web Audio API harmonic chime synthesizer (C5 -> E5).
  * `task-signalr.service.ts`: SignalR connector for TaskHub.
  * `signalr.service.ts`: App-wide SignalR service with TaskNotificationReceived & TaskBoardChanged handlers.
* `src/app/app.component.*`: Root component with global toast component mounted and SSR guards.
* `src/app/pages/all-dashboard/taskbox/`: Admin Taskbox routes and dashboard integration.
* `src/app/pages/all-employee/task-box/`: Employee Taskbox integration.

### 2. `WebAPI/`
* `Controllers/TaskManagerController.cs`: Task REST API endpoints & multi-hub SignalR real-time broadcaster.
* `Repository/TaskManagerRepository.cs` & `ITaskManagerRepository.cs`: Data access layer with stakeholder resolution for HOD/Assignee/Creator/Managers.
* `Models/TaskManagerModels.cs`: DTO models.
* `Hubs/ChatHub.cs`: Hub with role-based and bare group registration.
* `Hubs/TaskHub.cs`: Dedicated Task Hub.
* `Services/RecurringTaskHostedService.cs`: Background worker for recurrence spawning.
* `Program.cs`: Startup registrations.

### 3. `WebAPI/Scripts/` (SQL Stored Procedures & Tables)
* `HR_Task_Visibility_Phase08.sql`: Primary database script containing:
  * Tables: `HR_TaskMaster`, `HR_TaskActivityLog`, `HR_TaskStatusTransition_Config`, `HR_TaskRecurrencePattern`, `HR_TaskAttachment`.
  * Stored Procedures:
    * `dbo.usp_HR_Task_GetBoard`
    * `dbo.usp_HR_Task_Create`
    * `dbo.usp_HR_Task_Update`
    * `dbo.usp_HR_Task_UpdateStatusAndRemarks`
    * `dbo.usp_HR_Task_DispatchNotification`
    * `dbo.usp_HR_Task_ProcessRecurring`
* `HR_Task_Insert_Sidebar_Menu.sql`: Page registration and permissions script.
* Additional task fixes & migrations.

